THANK YOU FOR PURCHASING BLAZE AI ENGINE!


Make sure to import the tags and layers preset that comes with the asset called Tags&Layers. If you don't know how then please read the Importing Tags & Layers PDF first. THIS IS IMPORTANT.


PLEASE LEAVE YOUR FEEDBACK ON THE ASSET PAGE IF YOU LIKE BLAZE AI. IT HELPS ALOT! 