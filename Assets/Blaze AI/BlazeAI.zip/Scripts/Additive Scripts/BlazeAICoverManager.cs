using UnityEngine;

namespace BlazeAISpace
{
    public class BlazeAICoverManager : MonoBehaviour
    {
        // AI will dismiss this obstacle as cover if occupied
        public Transform occupiedBy;
    }
}
